require "test_helper"

class ProductPriceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
